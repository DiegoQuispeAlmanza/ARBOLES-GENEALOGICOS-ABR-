#include <iostream>
#include <locale.h>	// Implementacion de libreria para caracteres de lenguajes diferentes
#include <cstdio> 	// Funciones estandar de entrada/salida para std
#include <cstring> 	// Funciones para el manejo de arreglos
#include <string> 	// Para usar std::string en la visualizacion del arbol

using namespace std;

#define MAX_STR_LEN 64 // Definir la Longitud m�xima a 64 para todas las cadenas
int next_member_id = 1; // Contador global para IDs unicos

// ---------------- FUNCIONES DE UTILIDAD -----------------------

// Limpieza del buffer - Para evitar que el sistema realize una lectura con '\n' (causando repeticiones)
void limpiarBuffer() {
    cin.ignore(10000, '\n');
}

// ObtenerLinea - Para captar los caracteres ingresados 
void obtenerLinea(char buffer[]) {
    cin.getline(buffer, MAX_STR_LEN);
    if (cin.fail()) {
        cin.clear();
        limpiarBuffer();
        buffer[0] = '\0';
    }
}

// ConvertidorINT 
int convertirInt(const char* str) {
    int res = 0;
    int i = 0;
    while(str[i] != '\0') {
        if(str[i] >= '0' && str[i] <= '9') {
            res = res * 10 + (str[i] - '0');
        }
        i++;
    }
    return res;
}

// CompararCadenas - Realizar comparacion de caracteres, almacenados en dos arreglos auxiliares
bool compararCadenas(const char* a, const char* b) {
    int i = 0;
    while (a[i] != '\0' && b[i] != '\0') {
        if (a[i] != b[i]) return false;
        i++;
    }
    return a[i] == b[i];
}

// CopiarCadena - Copia simple de caracteres de un arreglo "origen" a otro "destino"
void copiarCadena(char* destino, const char* origen) {
    int i = 0;
    while ((destino[i] = origen[i]) != '\0') {
        i++;
    }
}

// intToChar - Convierte un numero entero a texto para guardarlo
void intToChar(int n, char buffer[]) {
    if (n == 0) {
        buffer[0] = '0';
        buffer[1] = '\0';
        return;
    }
    char temp[MAX_STR_LEN];
    int i = 0;
    while (n > 0) {
        temp[i++] = (n % 10) + '0';
        n /= 10;
    }
    int j = 0;
    while (i > 0) buffer[j++] = temp[--i];
    buffer[j] = '\0';
}

//=========================================================================================================

// ---------------- ESTRUCTURA DEL NODO ----------------

struct Nodo {
    char id[MAX_STR_LEN]; 					// ID: Identificador unico
    char nombre[MAX_STR_LEN];				// Nombre: 
    char fechaNacimiento[MAX_STR_LEN];		// Fecha (A�o):
    char titulo[MAX_STR_LEN]; 				// Titulo: Jerarquia o titulos nobles dentro de la familia (Don/Do�a)
    char etnia[MAX_STR_LEN];				// Etnia: Indica su etnia de origen (Penisnuslar, Espa�ol, Pueblo Quechua)
    
    Nodo* padre;	// Puntero al padre
    Nodo* madre;	// Puntero a la madre
    
    // Puntero al primer hijo o hijo izquierdo
    Nodo* hijoPrimero;       
    // Puntero al segundo hijo o hijo derecho
    Nodo* siguienteHermano;  
    
    bool visitado; 
};

// ----------------	ESTRUCTURA LOGICA PRINCIPAL DEL ARBOL ----------------

// CrearNodo - Crea un nuevo miembro reservando memoria y llenando datos
Nodo* crearNodo(const char* n, const char* fn, const char* t, const char* e) {
    Nodo* nodo = new Nodo();						// Reserva memoria para un nuevo nodo
    intToChar(next_member_id++, nodo->id); 
    copiarCadena(nodo->nombre, n);
    copiarCadena(nodo->fechaNacimiento, fn);
    copiarCadena(nodo->titulo, t);
    copiarCadena(nodo->etnia, e);
    
	// Inicializa todos los punteros en NULL por seguridad
    nodo->padre = NULL;
    nodo->madre = NULL;
    nodo->hijoPrimero = NULL;
    nodo->siguienteHermano = NULL;
    nodo->visitado = false;
    return nodo;
}

//=========================================================================================================

// ----------------	FUNCIONES GENERALES ----------------

// ImprimirDetalles - Muestra en pantalla la informacion del ID de los miembros
void imprimirDetalles(Nodo* nodo) {
    if (nodo == NULL) return;
    cout << "---------------------------------\n";
    cout << "ID: " << nodo->id << "\n";
    cout << "Nombre: " << nodo->titulo << " " << nodo->nombre << "\n";
    cout << "Nacimiento: " << nodo->fechaNacimiento << "\n";
    cout << "Etnia: " << nodo->etnia << "\n";
    if (nodo->padre) cout << "Padre: " << nodo->padre->nombre << " ID: " << nodo->padre->id << "\n";
    if (nodo->madre) cout << "Madre: " << nodo->madre->nombre << " ID: " << nodo->madre->id << "\n";
}

// LimpiarVisitados - Resetea la marca de visitado para futuros recorridos
void limpiarVisitadosRec(Nodo* nodo) {
    if (nodo == NULL) return;
    if (!nodo->visitado) return;
    nodo->visitado = false;
    limpiarVisitadosRec(nodo->hijoPrimero);
    limpiarVisitadosRec(nodo->siguienteHermano);
    limpiarVisitadosRec(nodo->padre);
    limpiarVisitadosRec(nodo->madre);
}

// BuscarNodoRec - Busca recursivamente un nodo por su nombre
Nodo* buscarNodoRec(Nodo* nodo, const char* nombreBuscar) {
    if (nodo == NULL || nodo->visitado) return NULL;
    nodo->visitado = true;

    if (compararCadenas(nodo->nombre, nombreBuscar)) return nodo;

    Nodo* encontrado = NULL;

    encontrado = buscarNodoRec(nodo->hijoPrimero, nombreBuscar);
    if (encontrado) return encontrado;

    encontrado = buscarNodoRec(nodo->siguienteHermano, nombreBuscar);
    if (encontrado) return encontrado;

    encontrado = buscarNodoRec(nodo->padre, nombreBuscar);
    if (encontrado) return encontrado;

    encontrado = buscarNodoRec(nodo->madre, nombreBuscar);
    if (encontrado) return encontrado;

    return NULL;
}

// BuscarNodo - Funcion principal para buscar que limpia banderas al final
Nodo* buscarNodo(Nodo* raiz, const char* nombreBuscar) {
    Nodo* res = buscarNodoRec(raiz, nombreBuscar);
    limpiarVisitadosRec(raiz); 
    return res;
}

//=========================================================================================================

// ----------------------- VALIDACIONES DE DATOS -----------------------

// Verifica que el padre sea mayor que el hijo y la diferencia sea logica
bool validarRelacionEdad(const char* fechaMayor, const char* fechaMenor) {
    int anioMayor = convertirInt(fechaMayor);
    int anioMenor = convertirInt(fechaMenor);

    if (anioMayor >= anioMenor) {
        cout << "ERROR CRONOLOGICO. El progenitor debe ser mayor que el hijo\n";
        return false;
    }
    int diferencia = anioMenor - anioMayor;
    if (diferencia > 40) {
        cout << "ERROR CRONOLOGICO. La diferencia de edad supera los 40 anios\n";
        return false;
    }
    return true;
}

// Funcion Validadora para convertir cadena a mayusculas
void convertirMAX(const char* original, char* destino) {
    int i = 0;
    while (original[i] != '\0' && i < MAX_STR_LEN - 1) {
        destino[i] = toupper(original[i]); 
        i++;
    }
    destino[i] = '\0';   
}

//=========================================================================================================

// ====== OPCION 1=====
// ----------------------- AGREGAR MIEMBROS CON RESTRICCION BINARIA -----------------------

// Intenta agregar un hijo verificando que no tenga mas de dos
bool agregarHijoAProgenitor(Nodo* progenitor, Nodo* nuevoNodo) {
    if (progenitor->hijoPrimero == NULL) {
        // Caso 1 No tiene hijos asi que este es el primero
        progenitor->hijoPrimero = nuevoNodo;
        return true;
    } else {
        // Caso 2 Ya tiene un hijo verificamos si cabe el segundo
        if (progenitor->hijoPrimero->siguienteHermano == NULL) {
            progenitor->hijoPrimero->siguienteHermano = nuevoNodo;
            return true;
        } else {
            // Caso 3 Ya tiene dos hijos y se rechaza el tercero
            return false; 
        }
    }
}

// Gestiona la creacion del vinculo hijo padre
void agregarComoHijo(Nodo* raiz, Nodo* nuevoNodo, const char* nombreProgenitor, char rol) {
    Nodo* progenitor = buscarNodo(raiz, nombreProgenitor);
    if (progenitor == NULL) {
        cout << "error progenitor no encontrado\n";
        delete nuevoNodo;
        return;
    }

    if (!validarRelacionEdad(progenitor->fechaNacimiento, nuevoNodo->fechaNacimiento)) {
        cout << "No se pudo agregar por fechas invalidas\n";
        delete nuevoNodo;
        return;
    }

    // Variable para saber si se pudo agregar
    bool agregado = false;

    if (rol == 'P' || rol == 'p') {
        if (nuevoNodo->padre == NULL) {
            // Intenta agregar verificando el maximo de hijos
            if (agregarHijoAProgenitor(progenitor, nuevoNodo)) {
                nuevoNodo->padre = progenitor;
                cout << "exito agregado como hijo\n";
            } else {
                cout << "ERROR El padre ya tiene el maximo de 2 hijos\n";
                delete nuevoNodo;
            }
        } else {
            cout << "error ya tiene padre\n";
            delete nuevoNodo;
        }
    } else if (rol == 'M' || rol == 'm') {
        if (nuevoNodo->madre == NULL) {
            if (agregarHijoAProgenitor(progenitor, nuevoNodo)) {
                nuevoNodo->madre = progenitor;
                cout << "exito agregado como hijo\n";
            } else {
                cout << "ERROR La madre ya tiene el maximo de 2 hijos\n";
                delete nuevoNodo;
            }
        } else {
            cout << "error ya tiene madre\n";
            delete nuevoNodo;
        }
    } else {
        cout << "error rol invalido\n";
        delete nuevoNodo;
    }
}

// Gestiona la creacion del vinculo padre hijo
void agregarComoProgenitor(Nodo* raiz, Nodo* nuevoNodo, const char* nombreHijo, char rol) {
    Nodo* hijo = buscarNodo(raiz, nombreHijo);
    if (hijo == NULL) {
        cout << "error hijo no encontrado\n";
        delete nuevoNodo;
        return;
    }

    if (!validarRelacionEdad(nuevoNodo->fechaNacimiento, hijo->fechaNacimiento)) {
        cout << "No se pudo agregar por fechas invalidas\n";
        delete nuevoNodo;
        return;
    }
    
    if (rol == 'P' || rol == 'p') {
        if (hijo->padre == NULL) {
            hijo->padre = nuevoNodo;
            // Al ser un padre nuevo el hijo existente es su primer hijo seguro
            agregarHijoAProgenitor(nuevoNodo, hijo); 
            cout << "exitoso agregado como padre\n";
        } else {
            cout << "error ya tiene padre\n";
            delete nuevoNodo;
            return;
        }
    } else if (rol == 'M' || rol == 'm') {
        if (hijo->madre == NULL) {
            hijo->madre = nuevoNodo;
            agregarHijoAProgenitor(nuevoNodo, hijo); 
            cout << "exito agregado como madre\n";
        } else {
            cout << "error ya tiene madre\n";
            delete nuevoNodo;
            return;
        }
    } else {
        cout << "error rol invalido\n";
        delete nuevoNodo;
        return;
    }
}

// Solicita datos al usuario para el nuevo miembro
void agregarMiembro(Nodo* raiz) {
    char nNombre[MAX_STR_LEN], nFechaNac[MAX_STR_LEN];
    char nTitulo[MAX_STR_LEN], nEtnia[MAX_STR_LEN];
    char opcionRel[MAX_STR_LEN], nombreRelacionado[MAX_STR_LEN], rolRelacion[4];

    cout << "\n--- agregar nuevo miembro ---\n";
    cout << "nombre: "; obtenerLinea(nNombre);
    if (nNombre[0] == '\0') { cout << "nombre vacio\n"; return; }
    cout << "fecha de nacimiento Anio: "; obtenerLinea(nFechaNac);
    cout << "titulo don o donia: "; obtenerLinea(nTitulo); 
    cout << "etnia: "; obtenerLinea(nEtnia);

    Nodo* nuevoNodo = crearNodo(nNombre, nFechaNac, nTitulo, nEtnia);

    cout << "\nselecciona H para hijo o P para padre madre\n";
    cout << "opcion: "; obtenerLinea(opcionRel);
    char tipo = opcionRel[0];

    if (tipo == 'H' || tipo == 'h') {
        cout << "nombre del antecesor existente: "; obtenerLinea(nombreRelacionado);
        cout << "indica si es P padre o M madre: "; obtenerLinea(rolRelacion);
        agregarComoHijo(raiz, nuevoNodo, nombreRelacionado, rolRelacion[0]);
    } else if (tipo == 'P' || tipo == 'p') {
        cout << "nombre del hijo existente: "; obtenerLinea(nombreRelacionado);
        cout << "indica si sera P padre o M madre: "; obtenerLinea(rolRelacion);
        agregarComoProgenitor(raiz, nuevoNodo, nombreRelacionado, rolRelacion[0]);
    } else {
        cout << "opcion incorrecta\n";
        delete nuevoNodo;
    }
}
//=========================================================================================================

// ====== OPCION 2=====
// ----------------------- ACTUALIZAR DATOS -----------------------

// Permite modificar la informacion de un miembro existente
void actualizarMiembro(Nodo* raiz) {
    char nombreBuscar[MAX_STR_LEN];
    cout << "\n--- actualizar miembro ---\n";
    cout << "nombre del miembro a editar: ";
    obtenerLinea(nombreBuscar);
    
    Nodo* nodo = buscarNodo(raiz, nombreBuscar);
    if (nodo == NULL) {
        cout << "miembro no encontrado\n";
        return;
    }

    imprimirDetalles(nodo);
    cout << "\nQue desea modificar\n";
    cout << "1 Nombre\n2 Fecha Nacimiento\n3 Titulo\n4 Etnia\n5 Cancelar\n";
    int opc = 0;
    cout << "Opcion: ";
    cin >> opc;
    limpiarBuffer();

    char buffer[MAX_STR_LEN];
    switch(opc) {
        case 1:
            cout << "Nuevo nombre: "; obtenerLinea(buffer);
            copiarCadena(nodo->nombre, buffer);
            break;
        case 2:
            cout << "Nueva fecha: "; obtenerLinea(buffer);
            cout << "Nota Verificar manualmente la consistencia\n";
            copiarCadena(nodo->fechaNacimiento, buffer);
            break;
        case 3:
            cout << "Nuevo titulo: "; obtenerLinea(buffer);
            copiarCadena(nodo->titulo, buffer);
            break;
        case 4:
            cout << "Nueva etnia: "; obtenerLinea(buffer);
            copiarCadena(nodo->etnia, buffer);
            break;
        case 5: return;
        default: cout << "Opcion invalida\n"; return;
    }
    cout << "Datos actualizados correctamente\n";
}

//=========================================================================================================

// ====== OPCION 3=====
// ----------------------- ELIMINAR MIEMBRO -----------------------

// Elimina un nodo y todos sus descendientes para evitar memoria perdida
void borrarSubArbol(Nodo* nodo) {
    if (nodo == NULL) return;
    borrarSubArbol(nodo->hijoPrimero);      
    borrarSubArbol(nodo->siguienteHermano); 
    delete nodo;
}

// Desconecta el nodo del arbol antes de borrarlo
void eliminarMiembro(Nodo*& raiz) {
    char nombreBuscar[MAX_STR_LEN];
    cout << "\n--- eliminar miembro ---\n";
    cout << "ADVERTENCIA Eliminar un miembro borrara tambien su descendencia\n";
    cout << "Nombre a eliminar: ";
    obtenerLinea(nombreBuscar);

    if (compararCadenas(raiz->nombre, nombreBuscar)) {
        cout << "No se puede eliminar la raiz principal aqui\n";
        return;
    }

    Nodo* objetivo = buscarNodo(raiz, nombreBuscar);
    if (objetivo == NULL) {
        cout << "Miembro no encontrado\n";
        return;
    }

    Nodo* padre = objetivo->padre;
    Nodo* madre = objetivo->madre;
    Nodo* antecesorHermano = NULL;

    Nodo* iter = NULL;
    if (padre != NULL) iter = padre->hijoPrimero;
    else if (madre != NULL) iter = madre->hijoPrimero;

    // Busca el hermano anterior si existe
    while (iter != NULL && iter != objetivo) {
        antecesorHermano = iter;
        iter = iter->siguienteHermano;
    }
    
    // Reajusta los punteros del padre o madre
    if (padre != NULL && padre->hijoPrimero == objetivo) {
        padre->hijoPrimero = objetivo->siguienteHermano;
    }
    if (madre != NULL && madre->hijoPrimero == objetivo) {
        madre->hijoPrimero = objetivo->siguienteHermano;
    }
    
    // Reajusta el puntero del hermano anterior
    if (antecesorHermano != NULL) {
        antecesorHermano->siguienteHermano = objetivo->siguienteHermano;
    }

    objetivo->siguienteHermano = NULL; 
    
    borrarSubArbol(objetivo);
    cout << "Miembro eliminado exitosamente\n";
}

//=========================================================================================================

// ====== OPCION 4=====
// ----------------------- VISUALIZACION DEL ARBOL -----------------------

// Dibuja el arbol usando caracteres y espacios
void mostrarArbolRecursivo(Nodo* nodo, string prefix, bool esUltimo) {
    if (nodo == NULL) return;
    if (nodo->visitado) return;
    nodo->visitado = true;

    cout << prefix;
    cout << (esUltimo ? "\\-- " : "+-- ");
    cout << nodo->titulo << " " << nodo->nombre
         << " (" << nodo->fechaNacimiento << ") ID:" << nodo->id << "\n";

    string newPrefix = prefix + (esUltimo ? "    " : "|   ");

    Nodo* hijoActual = nodo->hijoPrimero;
    while (hijoActual != NULL) {
        bool esUltimoHijo = (hijoActual->siguienteHermano == NULL);
        mostrarArbolRecursivo(hijoActual, newPrefix, esUltimoHijo);
        hijoActual = hijoActual->siguienteHermano;
    }
}

// Encuentra el ancestro mas alto disponible
Nodo* encontrarRaizSuperior(Nodo* nodo) {
    if (nodo == NULL) return NULL;
    while (nodo->padre != NULL || nodo->madre != NULL) {
        if (nodo->padre != NULL) {
            nodo = nodo->padre;
        } else {
            nodo = nodo->madre;
        }
    }
    return nodo;
}

// Muestra el arbol graficamente
void visualizarArbol(Nodo* nodoInicial) {
    if (nodoInicial == NULL) { cout << "Arbol vacio\n"; return; }
    cout << "\n--- arbol genealogico visual ---\n";
    Nodo* raizReal = encontrarRaizSuperior(nodoInicial);
    
    cout << raizReal->titulo << " " << raizReal->nombre 
         << " (" << raizReal->fechaNacimiento << ") ID:" << raizReal->id << "\n";
    
    raizReal->visitado = true;

    Nodo* hijo = raizReal->hijoPrimero;
    while (hijo != NULL) {
        bool esUltimo = (hijo->siguienteHermano == NULL);
        mostrarArbolRecursivo(hijo, "", esUltimo);
        hijo = hijo->siguienteHermano;
    }

    limpiarVisitadosRec(raizReal); 
}

// Lista los detalles de todos los miembros
void listarDetallesRec(Nodo* nodo) {
    if (nodo == NULL) return;
    if (nodo->visitado) return;
    nodo->visitado = true;

    imprimirDetalles(nodo);
    
    listarDetallesRec(nodo->padre);
    listarDetallesRec(nodo->madre);
    listarDetallesRec(nodo->hijoPrimero);
    listarDetallesRec(nodo->siguienteHermano);
}

void mostrarMiembros(Nodo* RAIZ) {
    if (RAIZ == NULL) return;
    cout << "\n----- lista completa de miembros -----\n";
    listarDetallesRec(RAIZ);
    limpiarVisitadosRec(RAIZ);
}

// Busca un miembro especifico y muestra sus detalles
void buscarMiembro(Nodo* RAIZ) {
    char nombreBuscar[MAX_STR_LEN];
    cout << "\n----- buscar miembro -----\n";
    cout << "nombre para buscar: ";
    obtenerLinea(nombreBuscar);
    if (nombreBuscar[0] == '\0') { cout << "debes ingresar un nombre\n"; return; }
    Nodo* resultado = buscarNodo(RAIZ, nombreBuscar);
    if (resultado != NULL) {
        cout << "miembro encontrado\n";
        imprimirDetalles(resultado);
    } else {
        cout << "no se encuentra al miembro\n";
    }
}

//=========================================================================================================

// ====== OPCION SUBMENU DE RECORRIDOS =====

// Recorrido PREORDEN (RID)
void recorridoPreOrden(Nodo* nodo) {
    if (nodo == NULL) return;
    cout << "[" << nodo->nombre << "] "; 
    recorridoPreOrden(nodo->hijoPrimero);    
    recorridoPreOrden(nodo->siguienteHermano); 
}

// Recorrido INORDEN (IRD)
void recorridoInOrden(Nodo* nodo) {
    if (nodo == NULL) return;
    recorridoInOrden(nodo->hijoPrimero);     
    cout << "[" << nodo->nombre << "] ";     
    recorridoInOrden(nodo->siguienteHermano);
}

// Recorrido POSTORDEN (IDR)
void recorridoPostOrden(Nodo* nodo) {
    if (nodo == NULL) return;
    recorridoPostOrden(nodo->hijoPrimero);      
    recorridoPostOrden(nodo->siguienteHermano); 
    cout << "[" << nodo->nombre << "] ";        
}

// INTERFAZ Submenu para elegir el tipo de ordenamiento
void menuRecorridos(Nodo* nodoInicial) {
    if (nodoInicial == NULL) return;
    int opc = 0;
    Nodo* raizReal = encontrarRaizSuperior(nodoInicial);
    
    do {
        cout << "\n--- SUBMENU recorridos ---\n";
        cout << "Raiz PADRE: " << raizReal->nombre << "\n";
        cout << "1. Pre-Orden\n";
        cout << "2. In-Orden\n";
        cout << "3. Post-Orden\n";
        cout << "4. Regresar\n";
        cout << "Opcion: ";
        cin >> opc;
        limpiarBuffer();

        switch(opc) {
            case 1: 
                cout << "\npre orden: ";
                recorridoPreOrden(raizReal); 
                cout << "\n";
                break;
            case 2: 
                cout << "\nin orden: ";
                recorridoInOrden(raizReal); 
                cout << "\n";
                break;
            case 3: 
                cout << "\npost orden: ";
                recorridoPostOrden(raizReal); 
                cout << "\n";
                break;
            case 4: break;
            default: cout << "opcion invalida\n";
        }
    } while (opc != 4);
}

//=========================================================================================================

// ====== INICIALIZACION DE LOS DATOS =====
// --- DATOS INICIALES ---

// INICIALIZA el arbol base integrado
Nodo* crearArbolBorjaLoyolaInca() {
    Nodo* Francisco = crearNodo("FRANCISCO", "1510", "Don", "Virreinal");		//NODO RAIZ
    Nodo* Juana = crearNodo("JUANA", "1520", "Do�a", "Inca"); 
    Nodo* Pedro = crearNodo("PEDRO", "1540", "Don", "Virreinal");
    Nodo* Maria = crearNodo("MARIA", "1542", "Do�a", "Virreinal"); 
    Nodo* Juan = crearNodo("JUAN", "1565", "Don", "Mestizo");
    Nodo* Ana = crearNodo("ANA", "1568", "Do�a", "Mestiza"); 
    Nodo* Carlos = crearNodo("CARLOS", "1570", "Don", "Mestizo");
    Nodo* Nieta = crearNodo("NINA", "1575", "Do�a", "Mestiza"); 

    Francisco->madre = Juana;			// La madre de FRANCISCO es JUANA
    
    // Se agregan los hijos respetando el limite de 2
    agregarHijoAProgenitor(Juana, Francisco); 

    agregarHijoAProgenitor(Francisco, Pedro);
    agregarHijoAProgenitor(Francisco, Maria);
    
    agregarHijoAProgenitor(Pedro, Juan);
    agregarHijoAProgenitor(Pedro, Nieta); 

    agregarHijoAProgenitor(Maria, Ana);
    agregarHijoAProgenitor(Maria, Carlos);
    
    Pedro->padre = Francisco;
    Maria->padre = Francisco;

    Juan->padre = Pedro;
    Nieta->padre = Pedro; 
    
    Ana->madre = Maria;
    Carlos->madre = Maria;

    return Francisco; 
}

//=========================================================================================================

// ====== EJECUCION DEL PROGRAMA =====

int main() {
    setlocale(LC_ALL, "Spanish");
    
    Nodo* RAIZ = crearArbolBorjaLoyolaInca();			// INICIALIZAR RAIZ

    int opcion = 0;
    
    cout << " ===============================================================\n";
    cout << "  Sistema de Arbol Genealogico - Familia Real Borja Loyola Inca \n";
    cout << " ===============================================================\n";

    do {
        cout << "\n Menu Principal\n";
        cout << "1. AGREGAR miembro\n";
        cout << "2. MOSTRAR todos los miembros\n";
        cout << "3. BUSCAR miembro\n";
        cout << "4. VISUALIZAR arbol genealogico\n";
        cout << "5. GENERAR recorridos\n";
        cout << "6. ACTUALIZAR miembro\n";
        cout << "7. ELIMINAR miembro\n";
        cout << "8. SALIR\n";
        cout << "Seleccione una opcion: ";

        if (!(cin >> opcion)) {
            cin.clear();
            limpiarBuffer();
            opcion = 0;
        } else {
            limpiarBuffer();
        }

        switch (opcion) {
            case 1: agregarMiembro(RAIZ); break;
            case 2: mostrarMiembros(RAIZ); break;
            case 3: buscarMiembro(RAIZ); break;
            case 4: visualizarArbol(RAIZ); break;
            case 5: menuRecorridos(RAIZ); break;
            case 6: actualizarMiembro(RAIZ); break;
            case 7: eliminarMiembro(RAIZ); break;
            case 8: cout << "Hasta pronto...!\n"; break;
            default:
                if (opcion != 0) cout << "Dato Invalido. Vuelva a intentarlo...\n";
        }
    } while (opcion != 8);

    return 0;
}
